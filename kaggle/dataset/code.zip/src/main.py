def main():
    print("Hello from gns!")


if __name__ == "__main__":
    main()
